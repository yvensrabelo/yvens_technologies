#!/bin/bash

# ============================================================================
# YVENS_TECHNOLOGIES v2.0 - Instalador de MCPs
# ============================================================================
# Script modular para instalação de MCPs sob demanda
# ============================================================================

set -e

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log() {
    echo -e "${1}${2}${NC}"
}

echo "🔌 Instalando MCPs - YVENS_TECHNOLOGIES v2.0"
echo "============================================="
echo ""

# Verificar se Claude CLI está disponível
if ! command -v claude &> /dev/null; then
    log $YELLOW "⚠️  Claude CLI não encontrado"
    log $BLUE "   MCPs serão configurados mas não instalados automaticamente"
    log $BLUE "   Instale Claude CLI: https://claude.ai/code"
    echo ""
    CLAUDE_AVAILABLE=false
else
    log $GREEN "✅ Claude CLI encontrado"
    CLAUDE_AVAILABLE=true
    echo ""
fi

# Lista de MCPs disponíveis
MCPS=(
    "context7:Context7 - Controle de contexto avançado"
    "supabase:Supabase - Backend como serviço"
    "filesystem:Filesystem - Manipulação de arquivos" 
    "playwright:Playwright - Automação de navegador"
    "mercadopago:Mercado Pago - Integração de pagamentos"
)

log $BLUE "🔌 MCPs disponíveis para instalação:"
for i in "${!MCPS[@]}"; do
    IFS=':' read -r mcp_name mcp_desc <<< "${MCPS[$i]}"
    log $GREEN "   $((i+1)). $mcp_desc"
done
echo ""

# Instalar MCPs selecionados
install_mcp() {
    local mcp_name=$1
    local mcp_desc=$2
    
    log $BLUE "📦 Instalando $mcp_desc..."
    
    case $mcp_name in
        "context7")
            install_context7
            ;;
        "supabase")
            install_supabase
            ;;
        "filesystem")
            install_filesystem
            ;;
        "playwright")
            install_playwright
            ;;
        "mercadopago")
            install_mercadopago
            ;;
    esac
}

# Context7 MCP
install_context7() {
    log $BLUE "   🎯 Configurando Context7 MCP..."
    
    if [ "$CLAUDE_AVAILABLE" = true ]; then
        # Tentar instalar via Claude CLI
        if claude mcp install context7 2>/dev/null; then
            log $GREEN "   ✅ Context7 instalado via Claude CLI"
        else
            setup_context7_manual
        fi
    else
        setup_context7_manual
    fi
}

setup_context7_manual() {
    log $YELLOW "   📝 Configuração manual necessária para Context7"
    
    # Criar configuração local
    mkdir -p "../config/mcps"
    cat > "../config/mcps/context7.json" << EOF
{
  "name": "context7",
  "description": "Context7 MCP - Controle de contexto avançado",
  "url": "https://github.com/context7/mcp-server",
  "installation": "npm install -g @context7/mcp-server",
  "configuration": {
    "api_key": "ctx7sk-YOUR-KEY-HERE",
    "endpoint": "https://api.context7.com/v1"
  }
}
EOF
    
    log $BLUE "   📁 Configuração salva em config/mcps/context7.json"
}

# Supabase MCP
install_supabase() {
    log $BLUE "   🗄️  Configurando Supabase MCP..."
    
    if [ "$CLAUDE_AVAILABLE" = true ]; then
        if claude mcp install supabase 2>/dev/null; then
            log $GREEN "   ✅ Supabase instalado via Claude CLI"
        else
            setup_supabase_manual
        fi
    else
        setup_supabase_manual
    fi
}

setup_supabase_manual() {
    log $YELLOW "   📝 Configuração manual necessária para Supabase"
    
    mkdir -p "../config/mcps"
    cat > "../config/mcps/supabase.json" << EOF
{
  "name": "supabase",
  "description": "Supabase MCP - Backend como serviço",
  "url": "https://github.com/supabase/mcp-server",
  "installation": "npm install -g @supabase/mcp-server",
  "configuration": {
    "project_url": "https://YOUR-PROJECT.supabase.co",
    "anon_key": "YOUR-ANON-KEY-HERE",
    "service_role_key": "YOUR-SERVICE-ROLE-KEY-HERE"
  }
}
EOF
    
    log $BLUE "   📁 Configuração salva em config/mcps/supabase.json"
}

# Filesystem MCP
install_filesystem() {
    log $BLUE "   📂 Configurando Filesystem MCP..."
    
    if [ "$CLAUDE_AVAILABLE" = true ]; then
        if claude mcp install filesystem 2>/dev/null; then
            log $GREEN "   ✅ Filesystem instalado via Claude CLI"
        else
            setup_filesystem_manual
        fi
    else
        setup_filesystem_manual
    fi
}

setup_filesystem_manual() {
    log $YELLOW "   📝 Configuração manual necessária para Filesystem"
    
    mkdir -p "../config/mcps"
    cat > "../config/mcps/filesystem.json" << EOF
{
  "name": "filesystem",
  "description": "Filesystem MCP - Manipulação de arquivos",
  "url": "https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem",
  "installation": "Built-in com Claude CLI",
  "configuration": {
    "allowed_directories": ["./", "../", "~/Documents/"]
  }
}
EOF
    
    log $BLUE "   📁 Configuração salva em config/mcps/filesystem.json"
}

# Playwright MCP
install_playwright() {
    log $BLUE "   🎭 Configurando Playwright MCP..."
    
    if [ "$CLAUDE_AVAILABLE" = true ]; then
        if claude mcp install playwright 2>/dev/null; then
            log $GREEN "   ✅ Playwright instalado via Claude CLI"
        else
            setup_playwright_manual
        fi
    else
        setup_playwright_manual
    fi
}

setup_playwright_manual() {
    log $YELLOW "   📝 Configuração manual necessária para Playwright"
    
    mkdir -p "../config/mcps"
    cat > "../config/mcps/playwright.json" << EOF
{
  "name": "playwright",
  "description": "Playwright MCP - Automação de navegador",
  "url": "https://github.com/modelcontextprotocol/servers/tree/main/src/playwright",
  "installation": "npm install -g @playwright/mcp-server",
  "configuration": {
    "browsers": ["chromium", "firefox", "webkit"],
    "headless": true
  }
}
EOF
    
    log $BLUE "   📁 Configuração salva em config/mcps/playwright.json"
}

# Mercado Pago MCP
install_mercadopago() {
    log $BLUE "   💳 Configurando Mercado Pago MCP..."
    
    # Mercado Pago é customizado, sempre configuração manual
    setup_mercadopago_manual
}

setup_mercadopago_manual() {
    log $YELLOW "   📝 Configuração manual necessária para Mercado Pago"
    
    mkdir -p "../config/mcps"
    cat > "../config/mcps/mercadopago.json" << EOF
{
  "name": "mercadopago",
  "description": "Mercado Pago MCP - Integração de pagamentos",
  "url": "https://github.com/yvensrabelo/mercadopago-mcp",
  "installation": "npm install -g mercadopago-mcp-server",
  "configuration": {
    "access_token": "YOUR-MP-ACCESS-TOKEN",
    "public_key": "YOUR-MP-PUBLIC-KEY",
    "sandbox": true
  }
}
EOF
    
    log $BLUE "   📁 Configuração salva em config/mcps/mercadopago.json"
}

# Instalar todos os MCPs
log $BLUE "🚀 Instalando MCPs selecionados..."
echo ""

for mcp_entry in "${MCPS[@]}"; do
    IFS=':' read -r mcp_name mcp_desc <<< "$mcp_entry"
    install_mcp "$mcp_name" "$mcp_desc"
done

echo ""
log $GREEN "✅ Instalação de MCPs concluída!"
echo ""

# Instruções finais
log $BLUE "📋 Próximos passos:"
if [ "$CLAUDE_AVAILABLE" = false ]; then
    log $YELLOW "   1. Instale Claude CLI: https://claude.ai/code"
    log $YELLOW "   2. Configure os MCPs usando os arquivos em config/mcps/"
else
    log $YELLOW "   1. Configure suas chaves nos arquivos de config/mcps/"
    log $YELLOW "   2. Reinicie Claude CLI: claude mcp list"
fi
log $YELLOW "   3. Teste os MCPs em seus projetos"
echo ""

log $GREEN "🎉 MCPs prontos para uso!"