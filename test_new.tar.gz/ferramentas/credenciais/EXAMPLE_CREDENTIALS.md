# 🔑 Exemplo de Credenciais - YVENS_TECHNOLOGIES v2.0

## 📋 **Como Configurar Suas Credenciais:**

1. **Copie este arquivo** e renomeie para `credentials.env`
2. **Substitua os valores de exemplo** pelas suas chaves reais
3. **Mantenha o arquivo seguro** - nunca compartilhe

---

## 🔐 **Template de Credenciais:**

```env
# ============================================
# YVENS_TECHNOLOGIES v2.0 - Credenciais
# ============================================
# IMPORTANTE: Substitua pelos seus valores reais
# ============================================

# Context7 API
CONTEXT7_API_KEY=ctx7sk-seu-token-aqui
CONTEXT7_ENDPOINT=https://api.context7.com/v1

# Supabase
SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_ANON_KEY=sua-anon-key-aqui
SUPABASE_SERVICE_KEY=sua-service-key-aqui

# Mercado Pago
MERCADOPAGO_ACCESS_TOKEN=seu-mp-access-token
MERCADOPAGO_PUBLIC_KEY=sua-mp-public-key
MERCADOPAGO_SANDBOX=true

# APIs Brasileiras (públicas - sem chave necessária)
BRASIL_API_URL=https://brasilapi.com.br/api
VIACEP_URL=https://viacep.com.br/ws

# Banco de Dados (opcional)
DATABASE_URL=postgresql://usuario:senha@localhost:5432/database

# Outras APIs (adicione conforme necessário)
OPENAI_API_KEY=sua-openai-key
GITHUB_TOKEN=seu-github-token
```

---

## 🛡️ **Segurança:**

### **✅ Faça:**
- Use valores reais nas suas credenciais
- Mantenha o arquivo `credentials.env` seguro
- Use diferentes chaves para dev/prod
- Rotacione chaves periodicamente

### **❌ Nunca:**
- Compartilhe suas chaves reais
- Commite credenciais no Git
- Use credenciais em código fonte
- Deixe chaves em logs

---

## 🔧 **Como Usar no Projeto:**

### **1. Copiar para Projeto:**
```bash
# Suas credenciais serão copiadas automaticamente quando escolher a opção
cp ferramentas/credenciais/credentials.env MeuProjeto/.env
```

### **2. Usar no Código:**
```javascript
// Node.js
require('dotenv').config();
const context7Key = process.env.CONTEXT7_API_KEY;

// Python
import os
from dotenv import load_dotenv
load_dotenv()
context7_key = os.getenv('CONTEXT7_API_KEY')
```

### **3. Verificar Carregamento:**
```bash
# Testar se variáveis estão disponíveis
echo $CONTEXT7_API_KEY
```

---

## 📊 **Status das Credenciais:**

### **🔌 MCPs:**
- **Context7**: ✅ Configurado
- **Supabase**: ✅ Configurado  
- **Mercado Pago**: ✅ Configurado

### **🌐 APIs Públicas:**
- **Brasil API**: ✅ Sem chave necessária
- **ViaCEP**: ✅ Sem chave necessária

### **🔧 Opcionais:**
- **OpenAI**: ⚠️ Configure se necessário
- **GitHub**: ⚠️ Para automações

---

## 🆘 **Onde Conseguir as Chaves:**

### **🎯 Context7:**
- Site: https://context7.com
- Documentação: API Keys section

### **🗄️ Supabase:**
- Dashboard: https://app.supabase.com
- Settings → API → Project API keys

### **💳 Mercado Pago:**
- Developers: https://www.mercadopago.com.br/developers
- Suas integrações → Credenciais

### **🤖 OpenAI:**
- Platform: https://platform.openai.com
- API Keys section

---

## 🎯 **Exemplo de Uso Completo:**

```bash
# 1. Configure suas credenciais
cp EXAMPLE_CREDENTIALS.md credentials.env
# Edite credentials.env com suas chaves

# 2. Use no projeto
# Credenciais são copiadas automaticamente durante instalação

# 3. Teste no código
node -e "require('dotenv').config(); console.log('Context7:', process.env.CONTEXT7_API_KEY ? 'OK' : 'Missing')"
```

**Suas credenciais estarão seguras e prontas para uso em qualquer projeto!** 🔒✨