#!/bin/bash

# ============================================================================
# YVENS_TECHNOLOGIES v2.0 - Download de Subagentes
# ============================================================================
# Script modular para download de subagentes Claude sob demanda
# ============================================================================

set -e

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log() {
    echo -e "${1}${2}${NC}"
}

echo "🤖 Baixando Subagentes Claude - YVENS_TECHNOLOGIES v2.0"
echo "======================================================"
echo ""

# Verificar se git está disponível
if ! command -v git &> /dev/null; then
    log $RED "❌ Git não encontrado!"
    log $YELLOW "   Instale git: https://git-scm.com/"
    exit 1
fi

log $GREEN "✅ Git encontrado"
echo ""

# URL do repositório de subagentes
SUBAGENTS_REPO="https://github.com/VoltaAgent/awesome-claude-code-subagents.git"
AGENTS_DIR="agents"

# Limpar instalação anterior se existir
if [ -d "$AGENTS_DIR" ]; then
    log $YELLOW "🗑️  Removendo instalação anterior de subagentes..."
    rm -rf "$AGENTS_DIR"
fi

# Clonar repositório de subagentes
log $BLUE "📦 Baixando subagentes do GitHub..."
log $BLUE "   Repositório: $SUBAGENTS_REPO"
echo ""

if git clone "$SUBAGENTS_REPO" "$AGENTS_DIR"; then
    log $GREEN "✅ Subagentes baixados com sucesso"
else
    log $RED "❌ Erro ao baixar subagentes"
    log $YELLOW "   Verifique sua conexão com a internet"
    exit 1
fi

# Remover pasta .git para economizar espaço
if [ -d "$AGENTS_DIR/.git" ]; then
    rm -rf "$AGENTS_DIR/.git"
    log $BLUE "🧹 Pasta .git removida (economia de espaço)"
fi

echo ""

# Contar subagentes disponíveis
if [ -d "$AGENTS_DIR/categories" ]; then
    agent_count=$(find "$AGENTS_DIR/categories" -name "*.md" 2>/dev/null | wc -l | tr -d ' ')
    log $GREEN "📊 $agent_count subagentes disponíveis"
else
    log $YELLOW "⚠️  Estrutura de categorias não encontrada"
    agent_count=0
fi

echo ""

# Listar categorias principais
log $BLUE "📂 Categorias de subagentes disponíveis:"
if [ -d "$AGENTS_DIR/categories" ]; then
    for category in "$AGENTS_DIR/categories"/*; do
        if [ -d "$category" ]; then
            category_name=$(basename "$category")
            category_count=$(find "$category" -name "*.md" 2>/dev/null | wc -l | tr -d ' ')
            log $GREEN "   📁 $category_name ($category_count subagentes)"
        fi
    done
else
    log $YELLOW "   ⚠️  Nenhuma categoria encontrada"
fi

echo ""

# Criar arquivo de índice de subagentes
log $BLUE "📝 Criando índice de subagentes..."
cat > "subagents-index.md" << EOF
# 🤖 Índice de Subagentes - YVENS_TECHNOLOGIES v2.0

Baixado em: $(date)
Total de subagentes: $agent_count

## 📂 Categorias Disponíveis:

EOF

if [ -d "$AGENTS_DIR/categories" ]; then
    for category in "$AGENTS_DIR/categories"/*; do
        if [ -d "$category" ]; then
            category_name=$(basename "$category")
            category_count=$(find "$category" -name "*.md" 2>/dev/null | wc -l | tr -d ' ')
            echo "### 📁 $category_name ($category_count subagentes)" >> "subagents-index.md"
            echo "" >> "subagents-index.md"
            
            # Listar subagentes da categoria
            find "$category" -name "*.md" 2>/dev/null | sort | while read -r agent_file; do
                agent_name=$(basename "$agent_file" .md)
                echo "- **$agent_name**" >> "subagents-index.md"
            done
            echo "" >> "subagents-index.md"
        fi
    done
fi

cat >> "subagents-index.md" << EOF
## 🚀 Como Usar:

1. **Explorar**: Navegue pelas pastas em \`agents/categories/\`
2. **Ler**: Cada subagente tem um arquivo .md com instruções
3. **Copiar**: Copie o prompt do subagente desejado
4. **Usar**: Cole no Claude Code para ativar o subagente

## 📋 Exemplos Populares:

- **frontend-developer**: Desenvolvimento React/Vue
- **backend-architect**: Arquitetura de sistemas
- **api-documenter**: Documentação automática
- **code-reviewer**: Revisão de código
- **test-automator**: Testes automatizados

**Explore e descubra o subagente perfeito para seu projeto!** 🎯
EOF

log $GREEN "✅ Índice criado: subagents-index.md"
echo ""

# Verificar integridade
if [ $agent_count -gt 0 ]; then
    log $GREEN "🎉 Download de subagentes concluído com sucesso!"
    echo ""
    
    log $BLUE "📋 Próximos passos:"
    log $YELLOW "   1. Leia: subagents-index.md"
    log $YELLOW "   2. Explore: agents/categories/"
    log $YELLOW "   3. Escolha subagentes para seu projeto"
    log $YELLOW "   4. Copie os prompts e use no Claude Code"
    echo ""
    
    log $BLUE "🎯 Localização dos subagentes:"
    log $YELLOW "   📂 $(pwd)/agents/"
    echo ""
    
else
    log $YELLOW "⚠️  Nenhum subagente encontrado"
    log $BLUE "   Verifique a estrutura do repositório"
fi

log $GREEN "✅ Subagentes prontos para uso!"