#!/bin/bash

# ============================================================================
# YVENS_TECHNOLOGIES v2.0 - Instalador BMAD Method
# ============================================================================
# Script modular para instalação da metodologia BMAD sob demanda
# ============================================================================

set -e

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

log() {
    echo -e "${1}${2}${NC}"
}

echo "🎯 Instalando BMAD Method - YVENS_TECHNOLOGIES v2.0"
echo "=================================================="
echo ""

# Verificar se git está disponível
if ! command -v git &> /dev/null; then
    log $RED "❌ Git não encontrado!"
    log $YELLOW "   Instale git: https://git-scm.com/"
    exit 1
fi

log $GREEN "✅ Git encontrado"
echo ""

# URL do repositório BMAD oficial
BMAD_OFFICIAL_REPO="https://github.com/bmad-code-org/BMAD-METHOD.git"
BMAD_DIR="bmad-ecosystem"

# Limpar instalação anterior
if [ -d "$BMAD_DIR" ]; then
    log $YELLOW "🗑️  Removendo instalação BMAD anterior..."
    rm -rf "$BMAD_DIR"
fi

# Baixar BMAD Method oficial do GitHub
log $BLUE "📦 Baixando BMAD Method oficial do GitHub..."
log $BLUE "   Repositório: $BMAD_OFFICIAL_REPO"
echo ""

if git clone "$BMAD_OFFICIAL_REPO" "$BMAD_DIR"; then
    log $GREEN "✅ BMAD Method oficial baixado com sucesso"
    
    # Remover pasta .git para economizar espaço
    if [ -d "$BMAD_DIR/.git" ]; then
        rm -rf "$BMAD_DIR/.git"
        log $BLUE "🧹 Pasta .git removida (economia de espaço)"
    fi
    
    echo ""
else
    log $RED "❌ Erro ao baixar BMAD Method oficial"
    log $YELLOW "   Verifique sua conexão com a internet"
    log $YELLOW "   Criando estrutura BMAD básica como fallback..."
    
    # Fallback - criar estrutura básica se GitHub falhar
    create_bmad_fallback
    return 0
fi

# Função fallback para criar estrutura básica
create_bmad_fallback() {
    log $BLUE "🏗️  Criando estrutura BMAD básica..."
    mkdir -p "$BMAD_DIR"/{core,workflows,templates,projects,agents,docs}
    
    # Criar README básico explicando o fallback
    cat > "$BMAD_DIR/README.md" << EOF
# BMAD Method - Fallback Structure

Este é um fallback básico da metodologia BMAD criado quando o repositório oficial não estava disponível.

## Repositório Oficial:
https://github.com/bmad-code-org/BMAD-METHOD

## Para obter a versão completa:
1. Verifique sua conexão com internet
2. Execute novamente o script de instalação
3. Ou clone manualmente: git clone https://github.com/bmad-code-org/BMAD-METHOD.git

**Esta versão básica fornece a estrutura fundamental, mas a versão oficial é recomendada.**
EOF
}

cd "$BMAD_DIR"

# Verificar se é estrutura oficial ou fallback
if [ -f "README.md" ] && grep -q "BMAD-METHOD" "README.md" 2>/dev/null; then
    log $GREEN "📚 Estrutura BMAD oficial detectada"
    
    # Listar conteúdo do repositório oficial
    log $BLUE "📁 Conteúdo BMAD oficial disponível:"
    if [ -d "methodology" ]; then
        log $GREEN "   ✅ Metodologia oficial"
    fi
    if [ -d "templates" ]; then
        log $GREEN "   ✅ Templates oficiais"
    fi
    if [ -d "examples" ]; then
        log $GREEN "   ✅ Exemplos práticos"
    fi
    if [ -d "tools" ]; then
        log $GREEN "   ✅ Ferramentas BMAD"
    fi
    
    # Criar links simbólicos ou cópias para integração
    log $BLUE "🔗 Integrando com YVENS_TECHNOLOGIES..."
    
else
    log $YELLOW "⚠️  Estrutura fallback detectada - complementando..."
    
    # Complementar com estrutura básica se necessário
    mkdir -p core/{config,lib,scripts}
    
    # Configuração principal do BMAD (apenas para fallback)
    cat > core/config/bmad.json << EOF
{
  "name": "BMAD Method",
  "version": "2.0.0",
  "description": "Breakthrough Method for Agile AI-Driven Development",
  "phases": {
    "planning": {
      "name": "Agentic Planning",
      "agents": ["business-analyst", "project-manager", "architect"],
      "deliverables": ["requirements.md", "architecture.md", "project-plan.md"]
    },
    "development": {
      "name": "Context-Engineered Development",
      "agents": ["story-master", "developer", "code-reviewer"],
      "deliverables": ["user-stories.md", "implementation/", "tests/"]
    },
    "quality": {
      "name": "Quality Assurance",
      "agents": ["qa-engineer", "test-automator", "performance-engineer"],
      "deliverables": ["test-results.md", "performance-report.md", "quality-metrics.md"]
    },
    "delivery": {
      "name": "Deployment & Delivery",
      "agents": ["devops-engineer", "deployment-specialist"],
      "deliverables": ["deployment-guide.md", "monitoring-setup.md"]
    }
  },
  "tools": {
    "planning": ["miro", "figma", "notion"],
    "development": ["vscode", "git", "docker"],
    "quality": ["jest", "cypress", "sonarqube"],
    "delivery": ["github-actions", "aws", "docker"]
  }
}
EOF

# Scripts de inicialização
cat > core/scripts/init-project.sh << 'EOF'
#!/bin/bash
# BMAD Project Initialization Script

PROJECT_NAME=$1
if [ -z "$PROJECT_NAME" ]; then
    echo "❌ Usage: ./init-project.sh <project-name>"
    exit 1
fi

echo "🎯 Initializing BMAD project: $PROJECT_NAME"
mkdir -p "../projects/$PROJECT_NAME"/{planning,development,quality,delivery}

echo "📝 Creating BMAD structure for $PROJECT_NAME..."
echo "✅ BMAD project $PROJECT_NAME initialized!"
EOF

chmod +x core/scripts/init-project.sh

# Workflows BMAD
log $BLUE "📋 Configurando BMAD Workflows..."
mkdir -p workflows/{web-app,mobile-app,api-development,data-science}

# Workflow Web App
cat > workflows/web-app/workflow.md << EOF
# 🌐 BMAD Workflow: Web Application

## Phase 1: Agentic Planning
1. **Business Analysis**
   - Define user personas
   - Identify core features
   - Create user journey maps

2. **Technical Architecture**
   - Choose tech stack
   - Design system architecture
   - Plan database schema

3. **Project Planning**
   - Break down into sprints
   - Estimate timeline
   - Define success metrics

## Phase 2: Context-Engineered Development
1. **Story Creation**
   - Write detailed user stories
   - Define acceptance criteria
   - Priority ranking

2. **Implementation**
   - Frontend development
   - Backend API development
   - Database implementation

3. **Code Review**
   - Architecture compliance
   - Code quality check
   - Security review

## Phase 3: Quality Assurance
1. **Testing**
   - Unit tests
   - Integration tests
   - E2E tests

2. **Performance**
   - Load testing
   - Performance optimization
   - Monitoring setup

## Phase 4: Delivery
1. **Deployment**
   - CI/CD setup
   - Production deployment
   - Monitoring configuration

2. **Documentation**
   - API documentation
   - User guides
   - Maintenance guides
EOF

# Templates BMAD
log $BLUE "📄 Configurando BMAD Templates..."
mkdir -p templates/{documents,code,configs}

# Template de README para projetos BMAD
cat > templates/documents/README-template.md << 'EOF'
# {{PROJECT_NAME}} - BMAD Project

Developed using BMAD (Breakthrough Method for Agile AI-Driven Development)

## 🎯 Project Overview
{{PROJECT_DESCRIPTION}}

## 🏗️ BMAD Phases

### Phase 1: Agentic Planning ✅
- [ ] Business Analysis
- [ ] Technical Architecture  
- [ ] Project Planning

### Phase 2: Context-Engineered Development 🚧
- [ ] Story Creation
- [ ] Implementation
- [ ] Code Review

### Phase 3: Quality Assurance ⏳
- [ ] Testing
- [ ] Performance
- [ ] Security

### Phase 4: Delivery 📦
- [ ] Deployment
- [ ] Documentation
- [ ] Maintenance

## 🛠️ Tech Stack
- Frontend: {{FRONTEND_TECH}}
- Backend: {{BACKEND_TECH}}
- Database: {{DATABASE_TECH}}
- Deployment: {{DEPLOYMENT_TECH}}

## 🤖 Agents Used
{{AGENTS_LIST}}

**Powered by BMAD Method & YVENS_TECHNOLOGIES** 🚀
EOF

# Agentes BMAD
log $BLUE "🤖 Configurando BMAD Agents..."
mkdir -p agents

cat > agents/bmad-agents.md << EOF
# 🤖 BMAD Specialized Agents

## Planning Phase Agents:
- **business-analyst**: Requirements and business logic
- **project-manager**: Timeline and resource planning  
- **architect**: System design and technical decisions

## Development Phase Agents:
- **story-master**: User story creation and management
- **developer**: Code implementation and features
- **code-reviewer**: Quality assurance and best practices

## Quality Phase Agents:
- **qa-engineer**: Test planning and execution
- **test-automator**: Automated testing setup
- **performance-engineer**: Performance optimization

## Delivery Phase Agents:
- **devops-engineer**: Deployment and infrastructure
- **deployment-specialist**: Production deployment
- **monitoring-specialist**: System monitoring setup

Each agent has specific expertise and works in coordination with others following the BMAD methodology.
EOF

# Documentação BMAD
log $BLUE "📚 Criando documentação BMAD..."
cat > docs/BMAD-Guide.md << EOF
# 🎯 BMAD Method Guide

## What is BMAD?
BMAD (Breakthrough Method for Agile AI-Driven Development) is a structured methodology that combines:
- **Agentic Planning**: AI agents assist in planning phases
- **Context-Engineered Development**: Context-aware development process
- **Quality-First Approach**: Quality integrated throughout
- **Agile Delivery**: Fast, iterative delivery cycles

## 4 Core Phases:

### 1. 📋 Agentic Planning
Use specialized AI agents for:
- Business analysis and requirements
- Technical architecture design
- Project planning and timeline

### 2. ⚡ Context-Engineered Development
- Context-aware story creation
- Implementation with full context
- Continuous code review

### 3. 🔍 Quality Assurance
- Comprehensive testing strategy
- Performance optimization
- Security validation

### 4. 🚀 Delivery
- Automated deployment
- Monitoring and maintenance
- Documentation and handoff

## Benefits:
- **Faster Development**: AI-assisted planning and development
- **Higher Quality**: Quality integrated throughout process
- **Better Architecture**: AI-guided technical decisions  
- **Predictable Delivery**: Structured phases with clear deliverables

**BMAD transforms traditional development into an AI-enhanced, quality-focused process.** 🎯
EOF

fi  # Fim do if-else para estrutura oficial vs fallback

cd .. # Voltar para o diretório anterior

echo ""
log $GREEN "✅ BMAD Method instalado com sucesso!"
echo ""

# Contar componentes instalados
component_count=0
[ -d "$BMAD_DIR/core" ] && ((component_count++))
[ -d "$BMAD_DIR/workflows" ] && ((component_count++)) 
[ -d "$BMAD_DIR/templates" ] && ((component_count++))
[ -d "$BMAD_DIR/agents" ] && ((component_count++))

log $BLUE "📊 Componentes BMAD instalados:"
log $GREEN "   ✅ Core: Framework principal"
log $GREEN "   ✅ Workflows: Templates de processo"
log $GREEN "   ✅ Templates: Modelos de documentos"
log $GREEN "   ✅ Agents: Agentes especializados"
log $GREEN "   📂 Total: $component_count componentes"
echo ""

log $BLUE "📋 Próximos passos:"
log $YELLOW "   1. Leia: $BMAD_DIR/docs/BMAD-Guide.md"
log $YELLOW "   2. Inicie projeto: cd $BMAD_DIR && ./core/scripts/init-project.sh MeuProjeto"
log $YELLOW "   3. Escolha workflow: $BMAD_DIR/workflows/"
log $YELLOW "   4. Use templates: $BMAD_DIR/templates/"
echo ""

log $CYAN "🎯 BMAD Method pronto para projetos estruturados!"
echo ""

log $GREEN "🎉 Instalação BMAD concluída!"